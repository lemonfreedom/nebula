<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>500 Internal Server Error</title>
    <style>
        body {
            background-color: #1d1f23;
        }

        .title {
            padding-top: 10%;
            color: #c7cacd;
            font-size: 2rem;
            font-family: Arial, Helvetica, sans-serif;
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="title">500 Internal Server Error</div>
</body>

</html>
