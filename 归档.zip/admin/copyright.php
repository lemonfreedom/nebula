<?php defined('NEBULA_ROOT_PATH') || exit; ?>
<div class="footer">
    <p>由 <a href="http://www.nebulaio.com">Nebula</a> 强力驱动</p>
    <p>
        <a href="">开发者文档</a>
        <a href="">GitHub 源码</a>
        <a href="">问题反馈</a>
    </p>
</div>
